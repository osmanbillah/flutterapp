// ignore_for_file: must_be_immutable

part of 'fixed_an_appointment_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///FixedAnAppointment widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class FixedAnAppointmentEvent extends Equatable {}

/// Event that is dispatched when the FixedAnAppointment widget is first created.
class FixedAnAppointmentInitialEvent extends FixedAnAppointmentEvent {
  @override
  List<Object?> get props => [];
}
