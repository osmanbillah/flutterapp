// ignore_for_file: must_be_immutable

part of 'fixed_an_appointment_bloc.dart';

/// Represents the state of FixedAnAppointment in the application.
class FixedAnAppointmentState extends Equatable {
  FixedAnAppointmentState({this.fixedAnAppointmentModelObj});

  FixedAnAppointmentModel? fixedAnAppointmentModelObj;

  @override
  List<Object?> get props => [
        fixedAnAppointmentModelObj,
      ];
  FixedAnAppointmentState copyWith(
      {FixedAnAppointmentModel? fixedAnAppointmentModelObj}) {
    return FixedAnAppointmentState(
      fixedAnAppointmentModelObj:
          fixedAnAppointmentModelObj ?? this.fixedAnAppointmentModelObj,
    );
  }
}
