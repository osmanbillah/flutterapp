import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:smartdoctor/presentation/fixed_an_appointment_screen/models/fixed_an_appointment_model.dart';
part 'fixed_an_appointment_event.dart';
part 'fixed_an_appointment_state.dart';

/// A bloc that manages the state of a FixedAnAppointment according to the event that is dispatched to it.
class FixedAnAppointmentBloc
    extends Bloc<FixedAnAppointmentEvent, FixedAnAppointmentState> {
  FixedAnAppointmentBloc(FixedAnAppointmentState initialState)
      : super(initialState) {
    on<FixedAnAppointmentInitialEvent>(_onInitialize);
  }

  _onInitialize(
    FixedAnAppointmentInitialEvent event,
    Emitter<FixedAnAppointmentState> emit,
  ) async {}
}
