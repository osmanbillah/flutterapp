import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:smartdoctor/presentation/smartdoctor_screen/models/smartdoctor_model.dart';
part 'smartdoctor_event.dart';
part 'smartdoctor_state.dart';

/// A bloc that manages the state of a Smartdoctor according to the event that is dispatched to it.
class SmartdoctorBloc extends Bloc<SmartdoctorEvent, SmartdoctorState> {
  SmartdoctorBloc(SmartdoctorState initialState) : super(initialState) {
    on<SmartdoctorInitialEvent>(_onInitialize);
  }

  _onInitialize(
    SmartdoctorInitialEvent event,
    Emitter<SmartdoctorState> emit,
  ) async {
    Future.delayed(const Duration(milliseconds: 3000), () {
      NavigatorService.popAndPushNamed(
        AppRoutes.loginScreen,
      );
    });
  }
}
