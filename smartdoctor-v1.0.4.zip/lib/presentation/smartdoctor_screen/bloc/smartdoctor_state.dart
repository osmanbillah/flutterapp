// ignore_for_file: must_be_immutable

part of 'smartdoctor_bloc.dart';

/// Represents the state of Smartdoctor in the application.
class SmartdoctorState extends Equatable {
  SmartdoctorState({this.smartdoctorModelObj});

  SmartdoctorModel? smartdoctorModelObj;

  @override
  List<Object?> get props => [
        smartdoctorModelObj,
      ];
  SmartdoctorState copyWith({SmartdoctorModel? smartdoctorModelObj}) {
    return SmartdoctorState(
      smartdoctorModelObj: smartdoctorModelObj ?? this.smartdoctorModelObj,
    );
  }
}
