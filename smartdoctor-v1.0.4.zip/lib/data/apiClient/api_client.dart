import 'package:smartdoctor/core/app_export.dart';

class ApiClient {}
